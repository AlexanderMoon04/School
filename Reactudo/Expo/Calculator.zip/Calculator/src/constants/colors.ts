import { Background } from "@react-navigation/elements";

export const Colors = {
   darkGray: '#2D2D2D',
   lightGray: '#9b9b9b',
   orange: '#FF9427',

   textPrimary: 'white',
   textSecondary:'#666666',
   background: '#000000',
} as const;